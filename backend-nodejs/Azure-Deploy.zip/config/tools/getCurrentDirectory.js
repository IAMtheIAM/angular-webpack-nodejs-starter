console.log(`Current Directory: ${process.cwd()}`);
